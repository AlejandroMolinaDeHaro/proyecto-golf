-- Backup 2026-06-14 23:07:22
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `carrito`;
CREATE TABLE `carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `producto_nombre` varchar(255) NOT NULL,
  `producto_precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mejor_jugador` text NOT NULL,
  `campo_torneo` text NOT NULL,
  `fecha_respuesta` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('3',NULL,'Jon Rahm','The Masters','2026-05-11 13:36:56');
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('5',NULL,'Rory McIlroy','US Open','2026-05-11 13:41:10');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `rol` varchar(20) DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`,`rol`) VALUES ('12','Administrador','admin@progolf.com','$2y$10$q2LA0S5wUMgUbmfx5PrwwOlADT/9ZAzyuUaOrVnei1iRFjbzoWNp6','2026-06-11 15:08:41','admin');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`,`rol`) VALUES ('13','pol','pol@gmail.com','$2y$10$9dbT8GB8A/pkq4yo0MXsruyXeiR.v6uwP55LGhHA9mzukXg45Nxsu','2026-06-11 16:45:45','user');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`,`rol`) VALUES ('14','pol','pol1@gmail.com','$2y$10$uFVwxOiQyJiu5ZDaEu9RbOzvJoykmyPUV9ZFtApsui4YrLOVSphWO','2026-06-12 15:57:34','user');

SET FOREIGN_KEY_CHECKS = 1;
