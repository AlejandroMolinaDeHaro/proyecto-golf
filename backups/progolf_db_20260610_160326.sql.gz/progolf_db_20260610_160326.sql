-- Backup 2026-06-10 16:03:27

DROP TABLE IF EXISTS `carrito`;
CREATE TABLE `carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `producto_nombre` varchar(255) NOT NULL,
  `producto_precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mejor_jugador` text NOT NULL,
  `campo_torneo` text NOT NULL,
  `fecha_respuesta` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('3',NULL,'Jon Rahm','The Masters','2026-05-11 13:36:56');
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('5',NULL,'Rory McIlroy','US Open','2026-05-11 13:41:10');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('7','pol','pol@gmail.com','$2y$10$qGZIk354iMvk3sSBuEFvIOVO67tjqKmzqw8o7j.3dbv6OwjmwRxZm','2026-06-03 15:52:59');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('8','uno','uno@gmail.com','$2y$10$nkgMz/3Lr0Fo8DssRRlcnuus5gl.m/hN.eunH4sOhyP8LGKd5MAEu','2026-06-03 15:53:16');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('9','rr','rr@gmail.com','$2y$10$QZph5ASY/Ti9Og6oNu6Rzei8.jwuxjw1vswOTZGodVMXuthbx487W','2026-06-10 16:03:15');
