-- Backup 2026-05-11 13:47:21

DROP TABLE IF EXISTS `carrito`;
CREATE TABLE `carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `producto_nombre` varchar(255) NOT NULL,
  `producto_precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `carrito` (`id`,`usuario_id`,`producto_nombre`,`producto_precio`,`cantidad`,`fecha_agregado`) VALUES ('1','1','Bolsa de Golf Titleist','329.00','1','2026-05-11 13:38:00');

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mejor_jugador` text NOT NULL,
  `campo_torneo` text NOT NULL,
  `fecha_respuesta` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('3',NULL,'Jon Rahm','The Masters','2026-05-11 13:36:56');
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('4','1','ergrg','frfrfrf','2026-05-11 13:37:44');
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('5',NULL,'Rory McIlroy','US Open','2026-05-11 13:41:10');
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_respuesta`) VALUES ('6','1','dd','wdw','2026-05-11 13:41:27');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('1','pol','pol@gmail.com','$2y$10$KMZccdgJ/JNSOqx3ZNBdM.q/y4wbaIlFlpyqsNuNby.Zl3Oel4XIO','2026-05-06 17:54:37');
