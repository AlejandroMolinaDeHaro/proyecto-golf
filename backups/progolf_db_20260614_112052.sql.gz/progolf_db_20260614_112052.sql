-- Backup 2026-06-14 11:21:01

DROP TABLE IF EXISTS `carrito`;
CREATE TABLE `carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `producto_nombre` varchar(255) NOT NULL,
  `producto_precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mejor_jugador` varchar(255) NOT NULL,
  `campo_torneo` varchar(255) NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
INSERT INTO `encuestas` (`id`,`usuario_id`,`mejor_jugador`,`campo_torneo`,`fecha_envio`) VALUES ('1','1','Jon Rahm','The Masters','2026-06-14 11:19:04');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(20) DEFAULT 'user',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`rol`,`fecha_registro`) VALUES ('1','Admin','admin@progolf.com','$2y$10$lh6herTcislxOj8xegQkZerXzQvk8M2LXQ.HLHM7LTAt.UuMaCaRK','admin','2026-06-14 11:18:27');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`rol`,`fecha_registro`) VALUES ('2','Usuario Test','user@test.com','$2y$10$FRuWCHRcVEcoonDS6kFNWenlx/aqDWEo2S78Y1H.xw2I8/8dNGcUe','user','2026-06-14 11:18:27');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`rol`,`fecha_registro`) VALUES ('3','Nuevo Usuario','nuevo@test.com','$2y$10$If7obHh4NT6TgAxpMMZA4OPUUrCL8f7LT3sV6iIXwrxTMAP5sNNji','user','2026-06-14 11:18:58');
