-- Backup 2026-05-26 16:45:09

DROP TABLE IF EXISTS `carrito`;
CREATE TABLE `carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `producto_nombre` varchar(255) NOT NULL,
  `producto_precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `encuestas`;
CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `mejor_jugador` text DEFAULT NULL,
  `campo_torneo` text DEFAULT NULL,
  `fecha_respuesta` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('1','pol','pol@gmail.com','$2y$10$I9M2F6IrsicIaS3keTuE8u2QI27hm5SYLRHUDo2UPtKOHiQz1pCUa','2026-05-26 16:30:40');
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password`,`fecha_registro`) VALUES ('3','ppp','ppp@gmail.com','$2y$10$7uwqj54SFVHgOXkBiu.cHeQFACPQK5ThBs6jFuQU3XRnQ8bHwTx2.','2026-05-26 16:43:51');
